public class Main {
    public static void main(String[] args) {
        String root = "https://www.manhuaniu.com/"; //网站根路径，用于拼接字符串
        String url = "https://www.manhuaniu.com/manhua/5830/";  //第一张第一页的url
        ComicSpider spider = new ComicSpider(url, root);
        spider.start();
    }
}
