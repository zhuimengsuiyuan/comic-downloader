public class ComicPage {
    private int number;  //每一页的序号
    private String url;  //每一页的链接

    public ComicPage(int number, String url) {
        this.number = number;
        this.url = url;
    }

    public int getNumber() {
        return number;
    }
    public String getUrl() {
        return url;
    }
}